import CountDown from "./actions/countDown.mjs";
import Click from "./actions/click.mjs";
import { Drag, Drop } from "./actions/dragNdrop.mjs";
import Tween from "./actions/tween.mjs";
import { Colide, Snap } from './actions/collision.mjs';




export { CountDown as NedTelling, Click as TrykkPaa, Drag as Dra, Drop as Slipp, Tween as Beveg, Colide as Kolisjon, Snap as Snapp }
